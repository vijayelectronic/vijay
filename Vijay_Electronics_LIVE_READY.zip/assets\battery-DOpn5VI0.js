import{c as t}from"./index-B_05fpwi.js";const e=[["path",{d:"M 22 14 L 22 10",key:"nqc4tb"}],["rect",{x:"2",y:"6",width:"16",height:"12",rx:"2",key:"13zb55"}]],o=t("battery",e);export{o as B};
